-- =====================================================================
-- METRIC 2: Free -> Premium Conversion Rate
-- ---------------------------------------------------------------------
-- WHY THIS MATTERS:
--   This is the headline monetisation metric for a freemium product.
--   We define an "active user" as anyone who submitted at least one
--   gamesession (i.e. actually used the product), then measure what share
--   of them ever became premium. A low rate points to either weak premium
--   value or a leaky upgrade funnel.
--
-- TABLES JOINED: gamesession  +  premium  (2 tables)
-- =====================================================================
SELECT
    COUNT(DISTINCT g.user_id)                                              AS active_users,
    COUNT(DISTINCT p.user_id)                                              AS converted_to_premium,
    ROUND(100.0 * COUNT(DISTINCT p.user_id) / COUNT(DISTINCT g.user_id), 2) AS conversion_rate_pct
FROM gamesession g
LEFT JOIN premium p ON p.user_id = g.user_id;
