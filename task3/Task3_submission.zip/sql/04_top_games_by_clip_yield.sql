-- =====================================================================
-- METRIC 4: Top Games by Volume & Clip Yield
-- ---------------------------------------------------------------------
-- WHY THIS MATTERS:
--   Eklipse runs a per-game AI model. Knowing which games drive the most
--   streams and clips - and which produce the most clips per stream
--   (yield) - tells the team where to invest model quality and where
--   marketing/partnerships will have the biggest payoff.
--
-- TABLES JOINED: gamesession  +  clips  (2 tables)
-- =====================================================================
SELECT
    g.game_name,
    COUNT(DISTINCT g.id)                          AS gamesessions,
    COUNT(c.id)                                   AS clips_generated,
    ROUND(1.0 * COUNT(c.id) / COUNT(DISTINCT g.id), 1) AS clips_per_session
FROM gamesession g
JOIN clips c ON c.gamesession_Id = g.id
GROUP BY g.game_name
ORDER BY clips_generated DESC
LIMIT 10;
