-- =====================================================================
-- METRIC 3: Premium Engagement Lift (clips per user: Premium vs Free)
-- ---------------------------------------------------------------------
-- WHY THIS MATTERS:
--   If premium users generate meaningfully more clips than free users, it
--   confirms the premium tier serves the heaviest, most engaged creators
--   and validates the value proposition. It also tells sales/growth who to
--   target for upsell: free users whose usage already looks "premium".
--
-- TABLES JOINED: clips (aggregated per user)  +  premium  (2 tables)
-- =====================================================================
WITH user_clips AS (
    SELECT user_id, COUNT(*) AS clips_made
    FROM clips
    GROUP BY user_id
)
SELECT
    CASE WHEN p.user_id IS NOT NULL THEN 'Premium' ELSE 'Free' END AS user_segment,
    COUNT(DISTINCT uc.user_id)            AS users,
    SUM(uc.clips_made)                    AS total_clips,
    ROUND(AVG(uc.clips_made), 1)          AS avg_clips_per_user
FROM user_clips uc
LEFT JOIN premium p ON p.user_id = uc.user_id
GROUP BY user_segment
ORDER BY avg_clips_per_user DESC;
