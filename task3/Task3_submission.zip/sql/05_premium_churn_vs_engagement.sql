-- =====================================================================
-- METRIC 5: Premium Churn & its link to Engagement
-- ---------------------------------------------------------------------
-- WHY THIS MATTERS:
--   Churn is the silent killer of any subscription business. Beyond the
--   raw churn rate (canceled / total premium), we check whether churned
--   members were *less engaged* (fewer clips) than retained ones. If so,
--   low early engagement becomes an actionable early-warning signal we can
--   act on before the cancellation happens.
--
-- TABLES JOINED: premium (aggregated per user)  +  clips (per user)  (2 tables)
-- =====================================================================
WITH prem AS (
    SELECT user_id,
           MAX(CASE WHEN canceled_at IS NOT NULL THEN 1 ELSE 0 END) AS ever_canceled
    FROM premium
    GROUP BY user_id
),
user_clips AS (
    SELECT user_id, COUNT(*) AS clips_made
    FROM clips
    GROUP BY user_id
)
SELECT
    CASE WHEN pr.ever_canceled = 1 THEN 'Churned' ELSE 'Retained' END AS premium_status,
    COUNT(DISTINCT pr.user_id)                        AS premium_users,
    ROUND(AVG(COALESCE(uc.clips_made, 0)), 1)         AS avg_clips_per_user
FROM prem pr
LEFT JOIN user_clips uc ON uc.user_id = pr.user_id
GROUP BY premium_status
ORDER BY premium_status;
