-- =====================================================================
-- METRIC 1: Clip Utilization Funnel (Generated -> Downloaded -> Shared)
-- ---------------------------------------------------------------------
-- WHY THIS MATTERS:
--   Eklipse's core promise is turning a stream into clips people actually
--   use. A clip that is generated but never downloaded or shared created
--   zero value. This funnel is the single best health check of whether the
--   AI output is relevant. Downloading & sharing are the CTT (convert-to-
--   tiktok) actions described in the brief.
--
-- TABLES JOINED: clips  +  downloaded_clips  +  shared_clips  (3 tables)
-- =====================================================================
SELECT
    COUNT(DISTINCT c.id)                                              AS clips_generated,
    COUNT(DISTINCT d.clip_id)                                         AS clips_downloaded,
    COUNT(DISTINCT s.clip_id)                                         AS clips_shared,
    ROUND(100.0 * COUNT(DISTINCT d.clip_id) / COUNT(DISTINCT c.id), 2) AS download_rate_pct,
    ROUND(100.0 * COUNT(DISTINCT s.clip_id) / COUNT(DISTINCT c.id), 2) AS share_rate_pct
FROM clips            c
LEFT JOIN downloaded_clips d ON d.clip_id = c.id
LEFT JOIN shared_clips     s ON s.clip_id = c.id;
